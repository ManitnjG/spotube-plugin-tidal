import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hetu_script/hetu_script.dart';

/// Test harness for the Tidal Spotube plugin.
/// Run with: flutter run (from the example/ directory)
/// Make sure to `make` the plugin first to generate the .smplug bytecode.
void main() {
  runApp(const PluginTestApp());
}

class PluginTestApp extends StatelessWidget {
  const PluginTestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tidal Plugin Test',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00FFFF), // Tidal teal
          brightness: Brightness.dark,
        ),
      ),
      home: const PluginTestScreen(),
    );
  }
}

class PluginTestScreen extends StatefulWidget {
  const PluginTestScreen({super.key});

  @override
  State<PluginTestScreen> createState() => _PluginTestScreenState();
}

class _PluginTestScreenState extends State<PluginTestScreen> {
  final _logs = <String>[];
  late final Hetu _hetu;
  dynamic _plugin;
  bool _loading = false;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _initHetu();
  }

  Future<void> _initHetu() async {
    setState(() => _loading = true);
    try {
      _hetu = Hetu();
      await _hetu.init();

      // Load compiled plugin bytecode
      final pluginFile = File('../spotube-plugin-tidal.smplug');
      if (!pluginFile.existsSync()) {
        _log('❌ Plugin not compiled. Run `make` first.');
        return;
      }

      final bytes = pluginFile.readAsBytesSync();
      _hetu.loadBytecode(bytes: bytes);
      _plugin = _hetu.invoke('TidalPlugin', positionalArgs: []);
      _log('✅ Plugin loaded: TidalPlugin');
      setState(() => _ready = true);
    } catch (e) {
      _log('❌ Init error: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  void _log(String msg) {
    setState(() => _logs.insert(0, '[${DateTime.now().toIso8601String().substring(11, 19)}] $msg'));
  }

  Future<void> _test(String label, Future<dynamic> Function() fn) async {
    _log('▶ $label...');
    try {
      final result = await fn();
      _log('✅ $label: ${result.toString().substring(0, result.toString().length.clamp(0, 120))}');
    } catch (e) {
      _log('❌ $label: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tidal Plugin Test'),
        backgroundColor: const Color(0xFF00FFFF),
        foregroundColor: Colors.black,
        actions: [
          if (_loading) const Padding(
            padding: EdgeInsets.all(16),
            child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
          ),
        ],
      ),
      body: Column(
        children: [
          // Test Buttons
          if (_ready) ...[
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _Btn('Login', Icons.login, () => _test('Auth', () async {
                    await _hetu.invoke('_plugin.auth.authenticate');
                    return 'Login initiated';
                  })),
                  _Btn('Me', Icons.person, () => _test('User/me', () async {
                    return await _hetu.invoke('_plugin.user.me');
                  })),
                  _Btn('Saved Tracks', Icons.favorite, () => _test('savedTracks', () async {
                    return await _hetu.invoke('_plugin.user.savedTracks',
                        namedArgs: {'offset': 0, 'limit': 5});
                  })),
                  _Btn('Playlists', Icons.queue_music, () => _test('savedPlaylists', () async {
                    return await _hetu.invoke('_plugin.user.savedPlaylists',
                        namedArgs: {'offset': 0, 'limit': 5});
                  })),
                  _Btn('Search', Icons.search, () => _test('search/all', () async {
                    return await _hetu.invoke('_plugin.search.all',
                        positionalArgs: ['Taylor Swift']);
                  })),
                  _Btn('Browse', Icons.explore, () => _test('browse/sections', () async {
                    return await _hetu.invoke('_plugin.browse.sections',
                        namedArgs: {'offset': 0, 'limit': 5});
                  })),
                  _Btn('Track Radio', Icons.radio, () => _test('track/radio', () async {
                    return await _hetu.invoke('_plugin.track.radio',
                        positionalArgs: ['251380837']); // Sample Tidal track ID
                  })),
                  _Btn('Logout', Icons.logout, () => _test('logout', () async {
                    await _hetu.invoke('_plugin.auth.logout');
                    return 'Logged out';
                  })),
                ],
              ),
            ),
          ] else if (!_loading)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('Plugin not loaded. Check logs below.'),
            ),

          // Log output
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: _logs.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final log = _logs[i];
                final isError = log.contains('❌');
                final isSuccess = log.contains('✅');
                return Text(
                  log,
                  style: TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 11,
                    color: isError
                        ? Colors.redAccent
                        : isSuccess
                            ? Colors.greenAccent
                            : Colors.white70,
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => setState(() => _logs.clear()),
        tooltip: 'Clear logs',
        child: const Icon(Icons.delete_outline),
      ),
    );
  }
}

class _Btn extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _Btn(this.label, this.icon, this.onTap);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 16),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF1A1A2E),
          foregroundColor: Colors.white,
        ),
      ),
    );
  }
}
